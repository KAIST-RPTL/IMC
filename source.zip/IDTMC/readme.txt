EB : extended boundary
AC : active core

from PIL import Image

im = Image.open("../fig.ppm")
im.save("fig.jpg")
